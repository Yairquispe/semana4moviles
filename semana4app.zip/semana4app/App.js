import React, { useState } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  Button, 
  StyleSheet, 
  TouchableOpacity,
  Alert 
} from 'react-native';

export default function App() {
  const [nombre, setNombre] = useState('');
  
  const [mensaje, setMensaje] = useState('');
  
  const [campoTocado, setCampoTocado] = useState(false);

  const esNombreValido = () => {
    return nombre.trim().length > 0;
  };

  const obtenerError = () => {
    if (campoTocado && !esNombreValido()) {
      return ' Por favor, ingresa tu nombre';
    }
    return '';
  };

  const manejarRegistro = () => {
    setCampoTocado(true);
    
    if (!esNombreValido()) {
      setMensaje('No olvides escribir tu nombre');
      return;
    }
    
    // Todo correcto ✅
    setMensaje(` Hola, ${nombre.trim()}! `);
  };

  const manejarBotonAlternativo = () => {
    if (!esNombreValido()) {
      Alert.alert(
        '¡Nombre requerido!',
        [
          { text: 'Entendido', onPress: () => setCampoTocado(true) }
        ]
      );
      return;
    }
    
    setMensaje(` ¡Genial, ${nombre.trim()}! Usaste el otro boton`);
  };

  const limpiarFormulario = () => {
    setNombre('');
    setMensaje('');
    setCampoTocado(false);
  };

  return (
    <View style={styles.pantalla}>
      <Text style={styles.titulo}>📝 Registro de usuario</Text>
      
      {/* Campo para escribir el nombre */}
      <View>
        <Text style={styles.etiqueta}>Nombre completo:</Text>
        <TextInput
          style={[
            styles.campoTexto,
            campoTocado && !esNombreValido() && styles.campoError
          ]}
          placeholder="Escribe tu nombre aquí"
          placeholderTextColor="#999"
          value={nombre}
          onChangeText={(texto) => {
            setNombre(texto);
            if (texto.trim().length > 0) {
              setCampoTocado(false);
            }
          }}
          onBlur={() => setCampoTocado(true)} 
        />
        {/* Mostrar mensaje de error debajo del campo */}
        {obtenerError() !== '' && (
          <Text style={styles.textoError}>{obtenerError()}</Text>
        )}
      </View>

      {/* Contador de caracteres (bonus) */}
      {nombre.length > 0 && (
        <Text style={styles.contadorCaracteres}>
          {nombre.length} caracteres
        </Text>
      )}
      
      {/* Botón estándar de React Native */}
      <View style={styles.separador}>
        <Button 
          title="Registrar" 
          onPress={manejarRegistro}
          color="#2196F3"
        />
      </View>
      
      <TouchableOpacity 
        style={styles.botonVerde} 
        onPress={manejarBotonAlternativo}
      >
        <Text style={styles.textoBotonVerde}>
          Usar botón alternativo
        </Text>
      </TouchableOpacity>

      {/* Botón para limpiar */}
      <TouchableOpacity 
        style={styles.botonLimpiar} 
        onPress={limpiarFormulario}
      >
        <Text style={styles.textoBotonLimpiar}>🧹 Limpiar formulario</Text>
      </TouchableOpacity>
      
      {/* Mostrar mensaje final */}
      {mensaje !== '' && (
        <View style={[
          styles.cajaMensaje,
          mensaje.includes('éxito') || mensaje.includes('Genial') 
            ? styles.cajaExito 
            : styles.cajaError
        ]}>
          <Text style={[
            styles.mensajeFinal,
            mensaje.includes('éxito') || mensaje.includes('Genial') 
              ? styles.textoExito 
              : styles.textoError
          ]}>
            {mensaje}
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  pantalla: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
    backgroundColor: '#f5f5f5',
  },
  
  titulo: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 25,
    textAlign: 'center',
    color: '#333',
  },
  
  etiqueta: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
    color: '#555',
  },
  
  campoTexto: {
    borderWidth: 2,
    borderColor: '#ddd',
    padding: 12,
    marginBottom: 5,
    borderRadius: 10,
    backgroundColor: '#fff',
    fontSize: 16,
  },
  
  campoError: {
    borderColor: '#ff6b6b',
    backgroundColor: '#fff5f5',
  },
  
  textoError: {
    color: '#d63031',
    fontSize: 14,
    marginBottom: 10,
    marginTop: 2,
    fontWeight: '500',
  },
  
  contadorCaracteres: {
    fontSize: 12,
    color: '#999',
    textAlign: 'right',
    marginBottom: 10,
  },
  
  separador: {
    marginBottom: 12,
    borderRadius: 8,
    overflow: 'hidden',
  },
  
  botonVerde: {
    backgroundColor: '#4CAF50',
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
  },
  
  textoBotonVerde: {
    color: '#ffffff',
    fontSize: 17,
    fontWeight: '600',
  },
  
  botonLimpiar: {
    backgroundColor: '#ff6b6b',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
  },
  
  textoBotonLimpiar: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  
  // Caja de mensajes
  cajaMensaje: {
    marginTop: 20,
    padding: 15,
    borderRadius: 10,
    borderLeftWidth: 5,
  },
  
  cajaExito: {
    backgroundColor: '#e8f5e9',
    borderLeftColor: '#4CAF50',
  },
  
  cajaError: {
    backgroundColor: '#ffebee',
    borderLeftColor: '#d63031',
  },
  
  mensajeFinal: {
    fontSize: 17,
    textAlign: 'center',
    fontWeight: '500',
  },
  
  textoExito: {
    color: '#2e7d32',
  },
  
  textoError: {
    color: '#d63031',
  },
});